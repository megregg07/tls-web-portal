======================================================================
OSAC/NIST TLS IPA DATA PROCESSING UTILITY - EXAMPLE DATASETS
======================================================================

This package contains two baseline sample datasets to demonstrate how 
the .csv/.txt data processing tool handles different input criteria.

The data contained in these example files consist strictly of 
Cartesian coordinates (X,Y,Z) from target centers extracted from a 
fixed target array. They do not contain raw scanner point clouds.

TECHNICAL CHARACTERISTICS:
1. Individual Coordinate Systems: Each of the four scanning position 
   files records its data using its own local reference point.
2. Non-Uniform Target Order: The sequence in which target coordinates 
   appear is not uniform across the files from scan to scan.

CONTENTS:
1. CSV Example Set
   - Contains exactly four (4) datasets representing scanning positions.
   - Files include a top structural header row.
   - CONFIGURATION: Set "Header Configuration Toggle" to YES.

2. TXT Example Set
   - Contains exactly four (4) datasets representing scanning positions.
   - Files do not include headers; numeric data starts on line 1.
   - CONFIGURATION: Set "Header Configuration Toggle" to NO.

EXPECTED OUTPUT:
The Data Processing Tool automatically matches identical targets across 
all setups, reorders rows to match the Position 1 baseline, and combines 
the files into a single consolidated .csv file ready for analysis using
the 'IPA Data Analysis Tool'.
======================================================================